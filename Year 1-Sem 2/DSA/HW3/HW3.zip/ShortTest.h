#pragma once

void testAll();
void test_add_occurence();